These are all historical releases.

Folders that say "Alpha" or "Beta" are not guaranteed to be stable. 
Folders that say "Release" should be reasonably stable.
